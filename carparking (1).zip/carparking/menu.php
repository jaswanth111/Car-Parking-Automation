<div id="sidebar-menu">
                    <!-- Left Menu Start -->
                    <ul class="metismenu" id="side-menu">
                        <li class="menu-title">Menu</li>
                        <li>
                            <a href="dashboard.php" class="waves-effect">
                                <i class="icon-accelerator"></i> Dashboard </span>
                            </a>
                        </li>

                        <li>
                            <a href="javascript:void(0);" class="waves-effect"><i class="icon-todolist-check"></i><span> ADD <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                            <ul class="submenu">
                                <li><a href="add-checkin.php">Add Check In</a></li>
								<li><a href="add-checkout.php">Add Check Out</a></li>
                                <li><a href="add-slot.php">Add New Slot</a></li>
								<li><a href="update-charge.php">Update Parking Charge</a></li>
                            </ul>
                        </li>

                       

                        <li>
                            <a href="javascript:void(0);" class="waves-effect"><i class="icon-spread"></i><span> REPORT <span class="float-right menu-arrow"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                            <ul class="submenu">
                                <li><a href="parking-list.php">Parking List</a></li>
                                <li><a href="slot-list.php">Slot List</a></li>
								<li><a href="parking-charge-list.php">Parking Charge</a></li>
                            </ul>
                        </li>

                        

                    </ul>

                </div>