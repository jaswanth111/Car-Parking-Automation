-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 01, 2021 at 11:08 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `carpark`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `charges`
--

CREATE TABLE IF NOT EXISTS `charges` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `charge` int(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `charge` (`charge`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `charges`
--

INSERT INTO `charges` (`id`, `charge`) VALUES
(1, 25);

-- --------------------------------------------------------

--
-- Table structure for table `entry`
--

CREATE TABLE IF NOT EXISTS `entry` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `carno` varchar(100) NOT NULL,
  `slotno` varchar(100) NOT NULL,
  `timein` varchar(100) NOT NULL,
  `timeout` varchar(100) NOT NULL,
  `charge` int(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `entry`
--

INSERT INTO `entry` (`id`, `date`, `carno`, `slotno`, `timein`, `timeout`, `charge`, `amount`) VALUES
(20, '2021-03-01', 'TN 07 F 8984', 'A3', '13:13:55', '14:30:7', 25, '31.75'),
(21, '2021-03-01', 'TN 54 AS 8956', 'A4', '13:20:35', '13:38:41', 25, '25'),
(22, '2021-03-01', 'TN 41 AD 8963', 'B1', '13:22:22', '16:39:27', 25, '82');

-- --------------------------------------------------------

--
-- Table structure for table `slot`
--

CREATE TABLE IF NOT EXISTS `slot` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `slotno` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slotno` (`slotno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `slot`
--

INSERT INTO `slot` (`id`, `slotno`, `status`) VALUES
(1, 'A1', ''),
(2, 'A2', ''),
(3, 'A3', ''),
(4, 'A4', ''),
(5, 'B1', ''),
(6, 'B2', ''),
(9, 'B3', ''),
(11, 'B4', '');
